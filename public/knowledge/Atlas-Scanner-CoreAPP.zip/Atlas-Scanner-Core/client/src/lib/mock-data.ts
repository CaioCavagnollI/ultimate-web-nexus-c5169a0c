export interface Muscle {
  name: string;
  role: 'prime' | 'synergist' | 'stabilizer';
}

export interface Exercise {
  id: string;
  name: string;
  equipmentIds: string[];
  muscles: Muscle[];
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  goal: 'Strength' | 'Hypertrophy' | 'Endurance';
}

export interface Equipment {
  id: string;
  name: string;
  aliases: string[];
  category: string;
}

export interface ScannerLog {
  id: string;
  timestamp: string;
  image?: string;
  detected: string[];
  finalId?: string;
  confidence: number;
}

// Mock Database
export const EQUIPMENT_DB: Equipment[] = [
  { id: 'eq_leg_press', name: '45° Leg Press', aliases: ['Leg Press', 'Incline Leg Press'], category: 'Legs' },
  { id: 'eq_chest_press', name: 'Seated Chest Press', aliases: ['Chest Press Machine', 'Vertical Chest Press'], category: 'Chest' },
  { id: 'eq_lat_pulldown', name: 'Lat Pulldown', aliases: ['Cable Pulldown', 'Lat Machine'], category: 'Back' },
  { id: 'eq_leg_ext', name: 'Leg Extension', aliases: ['Quad Extension'], category: 'Legs' },
  { id: 'eq_pec_fly', name: 'Pec Fly / Rear Delt', aliases: ['Peck Deck', 'Reverse Fly Machine'], category: 'Chest/Back' },
  { id: 'eq_smith_machine', name: 'Smith Machine', aliases: ['Smith Rack'], category: 'Multi' },
  { id: 'eq_cable_crossover', name: 'Cable Crossover', aliases: ['Dual Cable', 'Cable Tower'], category: 'Chest/Arms' },
];

export const EXERCISE_DB: Exercise[] = [
  { 
    id: 'ex_leg_press_standard', 
    name: 'Standard Leg Press', 
    equipmentIds: ['eq_leg_press'], 
    muscles: [{ name: 'Quadriceps', role: 'prime' }, { name: 'Gluteus Maximus', role: 'synergist' }, { name: 'Adductor Magnus', role: 'stabilizer' }],
    difficulty: 'Beginner',
    goal: 'Hypertrophy'
  },
  { 
    id: 'ex_leg_press_high', 
    name: 'High Foot Placement Leg Press', 
    equipmentIds: ['eq_leg_press'], 
    muscles: [{ name: 'Gluteus Maximus', role: 'prime' }, { name: 'Hamstrings', role: 'synergist' }, { name: 'Erector Spinae', role: 'stabilizer' }],
    difficulty: 'Intermediate',
    goal: 'Strength'
  },
  {
    id: 'ex_chest_press_neutral',
    name: 'Neutral Grip Chest Press',
    equipmentIds: ['eq_chest_press'],
    muscles: [{ name: 'Pectoralis Major', role: 'prime' }, { name: 'Triceps Brachii', role: 'synergist' }, { name: 'Anterior Deltoid', role: 'stabilizer' }],
    difficulty: 'Beginner',
    goal: 'Hypertrophy'
  },
  {
    id: 'ex_lat_pulldown_wide',
    name: 'Wide Grip Lat Pulldown',
    equipmentIds: ['eq_lat_pulldown'],
    muscles: [{ name: 'Latissimus Dorsi', role: 'prime' }, { name: 'Biceps Brachii', role: 'synergist' }, { name: 'Rotator Cuff', role: 'stabilizer' }],
    difficulty: 'Beginner',
    goal: 'Hypertrophy'
  },
  {
    id: 'ex_smith_squat',
    name: 'Smith Machine Squat',
    equipmentIds: ['eq_smith_machine'],
    muscles: [{ name: 'Quadriceps', role: 'prime' }, { name: 'Gluteus Maximus', role: 'synergist' }, { name: 'Core', role: 'stabilizer' }],
    difficulty: 'Intermediate',
    goal: 'Strength'
  }
];

export const SCANNER_LOGS: ScannerLog[] = [];
