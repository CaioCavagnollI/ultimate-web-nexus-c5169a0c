import { EQUIPMENT_DB, EXERCISE_DB, Equipment, Exercise } from './mock-data';

export interface ScanResult {
  scanId: string;
  identifiedEquipment: Equipment | null;
  candidates: Equipment[];
  confidenceScore: number;
  compatibleExercises: Exercise[];
  ragNotes: string; // Simulated RAG output
  evidence: string[]; // Citations
}

// Simulates the "Vision Top-K" and "Normalization" flow
export async function simulateScan(imageData: string): Promise<ScanResult> {
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 2000));

  // Deterministic "Mock" Logic based on randomness for demo purposes
  // In a real app, this would send image to Python backend
  
  const random = Math.random();
  let candidates: Equipment[] = [];
  
  // Simulate different detection scenarios
  if (random > 0.7) {
    // High confidence match: Leg Press
    candidates = [EQUIPMENT_DB[0], EQUIPMENT_DB[3]]; // Leg Press, Leg Ext
  } else if (random > 0.4) {
    // Ambiguous match: Chest Press vs Pec Fly
    candidates = [EQUIPMENT_DB[1], EQUIPMENT_DB[4]]; 
  } else {
    // Lat Pulldown
    candidates = [EQUIPMENT_DB[2]];
  }

  const topMatch = candidates[0];
  const confidence = 0.85 + (Math.random() * 0.14); // 0.85 - 0.99

  // Get compatible exercises
  const exercises = EXERCISE_DB.filter(ex => ex.equipmentIds.includes(topMatch.id));

  return {
    scanId: `scan_${Date.now()}`,
    identifiedEquipment: topMatch,
    candidates: candidates,
    confidenceScore: confidence,
    compatibleExercises: exercises,
    ragNotes: `Analysis based on visual configuration of seat mechanics and weight stack. The ${topMatch.name} allows for isolated training of the ${exercises[0]?.muscles[0].name || 'target muscle'} with stabilized trunk support.`,
    evidence: [
      "ProtocolLab Internal Kinetic Catalog v2.4",
      "Journal of Strength & Conditioning Res. (2024) - Isolation Mechanics"
    ]
  };
}
