import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Layout } from "@/components/layout";
import Home from "@/pages/home";
import Scanner from "@/pages/scanner";
import Library from "@/pages/library";
import Admin from "@/pages/admin";
import MobilePlan from "@/pages/mobile-plan";
import Integration from "@/pages/integration";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/scanner" component={Scanner} />
        <Route path="/library" component={Library} />
        <Route path="/admin" component={Admin} />
        <Route path="/mobile-plan" component={MobilePlan} />
        <Route path="/integration" component={Integration} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Toaster />
      <Router />
    </QueryClientProvider>
  );
}

export default App;
