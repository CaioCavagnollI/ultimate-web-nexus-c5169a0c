import { Link, useLocation } from "wouter";
import { Beaker, ScanLine, LayoutDashboard, Settings, Info, Share2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Beaker, label: "Lab" },
    { href: "/scanner", icon: ScanLine, label: "Scanner" },
    { href: "/library", icon: LayoutDashboard, label: "Library" },
    { href: "/integration", icon: Share2, label: "Integrate" },
    { href: "/admin", icon: Settings, label: "Admin" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col md:flex-row font-sans selection:bg-primary/20">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-72 border-r border-white/5 p-8 fixed h-full bg-zinc-950 z-50">
        <div className="mb-12 flex items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center border border-primary/20 text-primary shadow-[0_0_20px_rgba(59,130,246,0.1)]">
            <ScanLine className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-xl tracking-tighter font-mono">ATLAS<span className="text-primary">LAB</span></h1>
            <p className="text-[9px] text-zinc-500 font-mono tracking-widest uppercase">Protocol System v2.4</p>
          </div>
        </div>
        
        <nav className="flex flex-col gap-3">
          {navItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <div className={cn(
                "flex items-center gap-4 px-5 py-4 rounded-2xl transition-all text-sm font-semibold tracking-tight group cursor-pointer",
                location === item.href 
                  ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20" 
                  : "text-zinc-500 hover:text-white hover:bg-white/5"
              )}>
                <item.icon className={cn("w-5 h-5", location === item.href ? "text-primary-foreground" : "group-hover:text-primary")} />
                {item.label}
              </div>
            </Link>
          ))}
        </nav>

        <div className="mt-auto p-6 rounded-2xl bg-zinc-900/50 border border-white/5">
          <div className="flex items-center gap-2 mb-2 text-primary">
            <Info className="w-4 h-4" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Mobile Hub</span>
          </div>
          <p className="text-[11px] text-zinc-500 leading-relaxed mb-4">Access Atlas Protocols on the gym floor via React Native / Expo.</p>
          <Link href="/mobile-plan">
             <button className="w-full py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-colors">Access Guide</button>
          </Link>
        </div>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between px-6 py-5 border-b border-white/5 bg-zinc-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="flex items-center gap-3">
           <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20 text-primary">
            <ScanLine className="w-5 h-5" />
          </div>
          <span className="font-bold text-lg tracking-tighter font-mono uppercase">Atlas<span className="text-primary">Lab</span></span>
        </div>
        <div className="w-8 h-8 rounded-full bg-zinc-800 border border-white/10" />
      </header>

      {/* Main Content */}
      <main className="flex-1 md:ml-72 pb-24 md:pb-12">
        <div className="container max-w-5xl mx-auto px-6 py-8 md:py-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
          {children}
        </div>
      </main>

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-6 left-6 right-6 h-20 bg-zinc-950/90 backdrop-blur-2xl border border-white/10 rounded-3xl p-2 z-50 shadow-2xl flex items-center justify-around">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div className={cn(
              "relative flex flex-col items-center gap-1.5 p-3 rounded-2xl transition-all min-w-[64px] cursor-pointer",
              location === item.href 
                ? "text-primary" 
                : "text-zinc-600"
            )}>
              {location === item.href && (
                <motion.div layoutId="nav-pill" className="absolute inset-0 bg-primary/10 rounded-2xl" />
              )}
              <item.icon className={cn("w-6 h-6 z-10", location === item.href && "fill-current opacity-20")} />
              <span className="text-[9px] font-bold uppercase tracking-widest z-10">{item.label}</span>
            </div>
          </Link>
        ))}
      </nav>
    </div>
  );
}
