import { useState, useRef, useCallback } from "react";
import Webcam from "react-webcam";
import { Camera, RefreshCw, CheckCircle2, AlertCircle, ChevronRight, BrainCircuit, BookOpen, Fingerprint, ShieldAlert, Layers } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { simulateScan, ScanResult } from "@/lib/scanner-engine";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";

export default function Scanner() {
  const [step, setStep] = useState<'camera' | 'scanning' | 'results'>('camera');
  const [image, setImage] = useState<string | null>(null);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [activeTab, setActiveTab] = useState<'protocol' | 'evidence'>('protocol');
  const webcamRef = useRef<Webcam>(null);

  const capture = useCallback(() => {
    const imageSrc = webcamRef.current?.getScreenshot();
    if (imageSrc) {
      setImage(imageSrc);
      setStep('scanning');
      handleScan(imageSrc);
    }
  }, [webcamRef]);

  const handleScan = async (img: string) => {
    try {
      const data = await simulateScan(img);
      setResult(data);
      setStep('results');
    } catch (e) {
      console.error(e);
    }
  };

  const reset = () => {
    setImage(null);
    setResult(null);
    setStep('camera');
    setActiveTab('protocol');
  };

  const isLowConfidence = result && result.confidenceScore < 0.88;

  return (
    <div className="flex flex-col h-full max-h-[85vh] md:h-auto pb-20">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Fingerprint className="text-primary w-6 h-6" />
          Scanner Engine
        </h1>
        {step !== 'camera' && (
          <Button variant="ghost" size="sm" onClick={reset} className="text-muted-foreground hover:text-white">
            <RefreshCw className="w-4 h-4 mr-2" /> Recalibrate
          </Button>
        )}
      </div>

      <div className="flex-1 relative min-h-[500px] rounded-3xl overflow-hidden bg-black border border-white/10 shadow-2xl">
        <AnimatePresence mode="wait">
          {step === 'camera' && (
            <motion.div 
              key="camera"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 flex flex-col"
            >
              <div className="relative flex-1 bg-zinc-900 overflow-hidden">
                <Webcam
                  audio={false}
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  className="absolute inset-0 w-full h-full object-cover grayscale opacity-80"
                  videoConstraints={{ facingMode: "environment" }}
                />
                <div className="absolute inset-0 pointer-events-none border-[40px] border-black/40" />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                   <div className="w-72 h-72 border border-primary/30 rounded-full relative animate-pulse">
                      <div className="absolute inset-0 border-t-2 border-primary rounded-full rotate-45" />
                   </div>
                   <div className="absolute top-1/2 left-0 right-0 h-px bg-primary/20 scanner-overlay" />
                </div>
              </div>
              <div className="p-8 bg-zinc-950/90 backdrop-blur-md border-t border-white/10 flex flex-col items-center gap-4 z-10">
                <p className="text-[10px] font-mono text-zinc-500 tracking-[0.2em] uppercase">Visual Acquisition Ready</p>
                <Button 
                  size="lg" 
                  className="rounded-full w-20 h-20 p-0 border-8 border-primary/20 hover:border-primary/40 transition-all bg-primary text-primary-foreground shadow-[0_0_30px_rgba(59,130,246,0.3)]"
                  onClick={capture}
                >
                  <Camera className="w-8 h-8" />
                </Button>
              </div>
            </motion.div>
          )}

          {step === 'scanning' && image && (
            <motion.div 
              key="scanning"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black flex flex-col items-center justify-center p-8"
            >
              <img src={image} className="absolute inset-0 w-full h-full object-cover opacity-20 grayscale" alt="scanned" />
              <div className="absolute inset-0 scanner-overlay z-10" />
              <div className="relative z-20 flex flex-col items-center gap-6">
                <div className="relative">
                  <div className="w-24 h-24 border-2 border-primary/20 rounded-full" />
                  <div className="absolute inset-0 w-24 h-24 border-t-2 border-primary rounded-full animate-spin" />
                </div>
                <div className="text-center">
                  <p className="text-primary font-mono text-xs tracking-[0.3em] uppercase mb-2">Analyzing Morphology</p>
                  <p className="text-[10px] text-zinc-500 font-mono">TOP-K TAXONOMY MAPPING...</p>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'results' && result && (
            <motion.div 
              key="results"
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
              className="absolute inset-0 bg-zinc-950 flex flex-col"
            >
              <div className="relative h-56 shrink-0">
                <img src={image!} className="w-full h-full object-cover opacity-40 grayscale" alt="header" />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />
                <div className="absolute bottom-6 left-6 right-6">
                  <div className="flex items-center gap-3 mb-3">
                    <Badge variant="outline" className={cn(
                      "font-mono text-[10px] px-2 py-0.5 border-primary/30 bg-primary/10 text-primary",
                      isLowConfidence && "bg-amber-500/10 text-amber-500 border-amber-500/30"
                    )}>
                      {isLowConfidence ? 'LOW' : 'HIGH'} CONFIDENCE: {(result.confidenceScore * 100).toFixed(1)}%
                    </Badge>
                    <span className="text-zinc-600 font-mono text-[10px] uppercase tracking-widest">{result.scanId}</span>
                  </div>
                  <h2 className="text-4xl font-bold tracking-tight text-white">{result.identifiedEquipment?.name}</h2>
                </div>
              </div>

              <div className="flex-1 overflow-auto p-6 space-y-6">
                {/* Fallback Check */}
                {isLowConfidence && (
                  <div className="p-3 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
                    <ShieldAlert className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold text-amber-500 uppercase tracking-wider">Fallback Engaged</p>
                      <p className="text-[11px] text-amber-200/60 leading-tight mt-1">
                        Confidence score below threshold. Displaying broader equipment category mapping.
                      </p>
                    </div>
                  </div>
                )}

                {/* Navigation Tabs */}
                <div className="flex border-b border-white/5">
                  <button 
                    onClick={() => setActiveTab('protocol')}
                    className={cn(
                      "px-4 py-2 text-xs font-bold uppercase tracking-widest transition-colors relative",
                      activeTab === 'protocol' ? "text-primary" : "text-zinc-500"
                    )}
                  >
                    Protocols
                    {activeTab === 'protocol' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
                  </button>
                  <button 
                    onClick={() => setActiveTab('evidence')}
                    className={cn(
                      "px-4 py-2 text-xs font-bold uppercase tracking-widest transition-colors relative",
                      activeTab === 'evidence' ? "text-primary" : "text-zinc-500"
                    )}
                  >
                    Evidence
                    {activeTab === 'evidence' && <motion.div layoutId="tab" className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary" />}
                  </button>
                </div>

                <AnimatePresence mode="wait">
                  {activeTab === 'protocol' ? (
                    <motion.div 
                      key="protocol" 
                      initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }}
                      className="space-y-4"
                    >
                      {result.compatibleExercises.map((ex) => (
                        <Card key={ex.id} className="group overflow-hidden bg-zinc-900/50 border-white/5 hover:border-primary/30 transition-all cursor-pointer">
                          <div className="flex items-stretch">
                            <div className="w-1.5 bg-zinc-800 group-hover:bg-primary transition-colors shrink-0" />
                            <div className="p-4 flex-1">
                              <div className="flex justify-between items-start mb-3">
                                <h4 className="font-bold text-zinc-100 group-hover:text-primary transition-colors">{ex.name}</h4>
                                <ChevronRight className="w-4 h-4 text-zinc-700 group-hover:text-primary transition-colors" />
                              </div>
                              <div className="grid grid-cols-3 gap-2">
                                {ex.muscles.map((m, i) => (
                                  <div key={i} className="space-y-1">
                                    <p className="text-[9px] uppercase font-mono text-zinc-600 tracking-tighter">{m.role}</p>
                                    <p className={cn(
                                      "text-[10px] font-bold truncate",
                                      m.role === 'prime' ? "text-primary" : "text-zinc-400"
                                    )}>{m.name}</p>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        </Card>
                      ))}
                    </motion.div>
                  ) : (
                    <motion.div 
                      key="evidence"
                      initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -10 }}
                      className="space-y-4"
                    >
                      <div className="p-5 rounded-2xl bg-primary/5 border border-primary/10 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                          <Layers className="w-12 h-12 text-primary" />
                        </div>
                        <div className="relative z-10">
                          <div className="flex items-center gap-2 mb-3">
                            <BrainCircuit className="w-4 h-4 text-primary" />
                            <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-primary">RAG Analysis Contract</span>
                          </div>
                          <p className="text-xs text-zinc-300 leading-relaxed italic">
                            "{result.ragNotes}"
                          </p>
                        </div>
                      </div>

                      <div className="space-y-2">
                         <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest pl-1">Citations Registry</p>
                         {result.evidence.map((cit, i) => (
                           <div key={i} className="flex items-center gap-3 p-3 rounded-lg bg-zinc-900 border border-white/5 group hover:border-zinc-700 transition-colors">
                             <BookOpen className="w-4 h-4 text-zinc-600 group-hover:text-primary" />
                             <span className="text-[11px] font-mono text-zinc-400 group-hover:text-zinc-200">{cit}</span>
                           </div>
                         ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
