import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { EXERCISE_DB } from "@/lib/mock-data";
import { useState } from "react";

export default function Library() {
  const [term, setTerm] = useState("");

  const filtered = EXERCISE_DB.filter(ex => 
    ex.name.toLowerCase().includes(term.toLowerCase()) || 
    ex.muscles.some(m => m.name.toLowerCase().includes(term.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
           <h1 className="text-2xl font-bold tracking-tight">Exercise Catalog</h1>
           <p className="text-muted-foreground text-sm">Standardized protocols and movement patterns.</p>
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search movements..." 
            className="pl-9 bg-zinc-900 border-white/10" 
            value={term}
            onChange={e => setTerm(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(ex => (
          <Card key={ex.id} className="bg-zinc-900/50 border-white/5 p-5 hover:border-primary/20 transition-all">
            <div className="flex justify-between items-start mb-4">
               <Badge variant="outline" className="bg-primary/5 text-primary border-primary/20">{ex.goal}</Badge>
               <span className="text-xs text-muted-foreground font-mono">{ex.id}</span>
            </div>
            <h3 className="font-bold text-lg mb-1">{ex.name}</h3>
            
            <div className="space-y-3 mt-4">
               <div>
                 <p className="text-[10px] uppercase text-muted-foreground font-bold tracking-wider mb-1">Target Muscles</p>
                 <div className="flex flex-wrap gap-1">
                   {ex.muscles.map((m, i) => (
                     <span key={i} className="text-xs px-1.5 py-0.5 rounded bg-white/5 text-zinc-300 border border-white/5">
                       {m.name}
                     </span>
                   ))}
                 </div>
               </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
