import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Activity, ShieldCheck, Database, Zap } from "lucide-react";

export default function Home() {
  return (
    <div className="space-y-12">
      <section className="relative py-12 md:py-24 overflow-hidden rounded-3xl bg-zinc-900/50 border border-white/5">
        <div className="absolute inset-0 grid-bg opacity-30 pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/20 to-background pointer-events-none" />
        
        <div className="relative z-10 px-6 md:px-12 flex flex-col items-start gap-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-mono font-medium">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
            </span>
            SYSTEM ONLINE: v2.4.0
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tighter max-w-2xl bg-gradient-to-r from-white to-white/50 bg-clip-text text-transparent">
            Science & Strength Protocol
          </h1>
          
          <p className="text-lg text-muted-foreground max-w-lg leading-relaxed">
            Advanced equipment analysis and deterministic protocol generation governed by the Atlas RAG engine.
          </p>
          
          <div className="flex gap-4 mt-4">
            <Link href="/scanner">
              <Button size="lg" className="h-12 px-8 bg-primary hover:bg-primary/90 text-primary-foreground font-semibold rounded-full group">
                Initiate Scan 
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
            <Link href="/library">
              <Button size="lg" variant="outline" className="h-12 px-8 border-white/10 hover:bg-white/5 rounded-full">
                View Catalog
              </Button>
            </Link>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <FeatureCard 
          icon={Activity}
          title="Vision Analysis" 
          desc="Proprietary Top-K computer vision model for equipment identification." 
        />
        <FeatureCard 
          icon={ShieldCheck}
          title="Governed RAG" 
          desc="Evidence-backed protocol generation with strict citation requirements." 
        />
        <FeatureCard 
          icon={Database}
          title="Taxonomy Norms" 
          desc="Standardized equipment labeling mapping aliases to canonical IDs." 
        />
      </div>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) {
  return (
    <div className="p-6 rounded-2xl bg-zinc-900/30 border border-white/5 hover:border-primary/20 transition-colors group">
      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center mb-4 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
        <Icon className="w-5 h-5" />
      </div>
      <h3 className="font-semibold text-lg mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </div>
  );
}
