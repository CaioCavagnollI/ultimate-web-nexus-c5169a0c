import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { EQUIPMENT_DB } from "@/lib/mock-data";
import { Badge } from "@/components/ui/badge";

export default function Admin() {
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold tracking-tight">
        System Administration
      </h1>

      <Tabs defaultValue="taxonomy" className="w-full">
        <TabsList className="bg-zinc-900 border border-white/10">
          <TabsTrigger value="taxonomy">Taxonomy</TabsTrigger>
          <TabsTrigger value="logs">Scanner Logs</TabsTrigger>
          <TabsTrigger value="config">Configuration</TabsTrigger>
        </TabsList>

        <TabsContent value="taxonomy" className="mt-6">
          <Card className="bg-zinc-900/50 border-white/5">
            <CardHeader>
              <CardTitle>Equipment Taxonomy</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-white/10 hover:bg-transparent">
                    <TableHead>ID</TableHead>
                    <TableHead>Canonical Name</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Known Aliases</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {EQUIPMENT_DB.map((eq) => (
                    <TableRow
                      key={eq.id}
                      className="border-white/10 hover:bg-white/5"
                    >
                      <TableCell className="font-mono text-xs text-muted-foreground">
                        {eq.id}
                      </TableCell>
                      <TableCell className="font-medium">{eq.name}</TableCell>
                      <TableCell>{eq.category}</TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {eq.aliases.map((alias, i) => (
                            <Badge
                              key={i}
                              variant="secondary"
                              className="text-[10px] bg-white/5 hover:bg-white/10"
                            >
                              {alias}
                            </Badge>
                          ))}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="logs">
          <div className="p-12 text-center text-muted-foreground border border-dashed border-white/10 rounded-xl">
            No logs recorded in this session yet.
          </div>
        </TabsContent>

        <TabsContent value="config">
          <div className="grid gap-4">
            <ConfigItem label="SCANNER_MIN_QUALITY" value="0.65" />
            <ConfigItem label="SCANNER_MIN_VISION_CONF" value="0.80" />
            <ConfigItem label="RAG_MIN_SCORE" value="0.75" />
            <ConfigItem label="RAG_MIN_HITS" value="3" />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function ConfigItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between p-4 bg-zinc-900 border border-white/5 rounded-lg">
      <span className="font-mono text-sm text-zinc-400">{label}</span>
      <span className="font-mono text-sm text-primary">{value}</span>
    </div>
  );
}
