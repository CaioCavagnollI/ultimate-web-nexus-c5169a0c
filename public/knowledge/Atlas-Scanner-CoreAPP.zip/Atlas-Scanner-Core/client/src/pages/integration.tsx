import { useState } from "react";
import { Copy, Check, Code, Globe, ShieldCheck, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Integration() {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const iframeCode = `<iframe 
  src="https://atlas-scanner.replit.app/embed/score" 
  width="100%" 
  height="400" 
  style="border:none; border-radius:12px;"
  allow="camera"
></iframe>`;

  const sdkCode = `import { AtlasScanner } from '@atlaslab/protocol-sdk';

const scanner = new AtlasScanner({
  apiKey: 'YOUR_PROTOCOL_KEY',
  theme: 'dark'
});

scanner.on('match', (data) => {
  console.log('Equipment ID:', data.equip_id);
  console.log('Confidence:', data.confidence_score);
});`;

  return (
    <div className="max-w-4xl mx-auto space-y-12 pb-20">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight bg-gradient-to-r from-white to-zinc-500 bg-clip-text text-transparent">
          Atlas Integration Hub
        </h1>
        <p className="text-zinc-400 text-lg">
          Incorpore a inteligência do Atlas Scanner Score em qualquer plataforma com nossas soluções de integração.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <IntegrationType 
          icon={Globe}
          title="Embed (IFrame)"
          desc="A forma mais rápida de adicionar o scanner ao seu site existente."
        />
        <IntegrationType 
          icon={Code}
          title="Protocol SDK"
          desc="Integração profunda para apps React, Vue ou Vanilla JS."
        />
        <IntegrationType 
          icon={Zap}
          title="Webhooks"
          desc="Receba resultados de escaneamento diretamente no seu backend."
        />
      </div>

      <Card className="bg-zinc-900 border-white/5 overflow-hidden">
        <Tabs defaultValue="embed" className="w-full">
          <div className="px-8 pt-6 border-b border-white/5 flex items-center justify-between">
            <TabsList className="bg-transparent border-none gap-6">
              <TabsTrigger value="embed" className="data-[state=active]:text-primary text-zinc-500 font-bold uppercase tracking-widest text-xs p-0 pb-4 rounded-none">Embed Code</TabsTrigger>
              <TabsTrigger value="sdk" className="data-[state=active]:text-primary text-zinc-500 font-bold uppercase tracking-widest text-xs p-0 pb-4 rounded-none">JS SDK</TabsTrigger>
            </TabsList>
            <div className="pb-4">
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => copyToClipboard(iframeCode)}
                className="text-zinc-500 hover:text-white"
              >
                {copied ? <Check className="w-4 h-4 mr-2" /> : <Copy className="w-4 h-4 mr-2" />}
                {copied ? 'Copied' : 'Copy Code'}
              </Button>
            </div>
          </div>

          <TabsContent value="embed" className="p-0">
            <pre className="p-8 font-mono text-sm text-primary/80 bg-black/40 overflow-x-auto leading-relaxed">
              {iframeCode}
            </pre>
            <div className="p-6 bg-zinc-950/50 border-t border-white/5">
              <div className="flex items-center gap-3 text-amber-500/80">
                <ShieldCheck className="w-5 h-5" />
                <p className="text-xs font-medium">Requer permissões de câmera via HTTPS no domínio pai.</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sdk" className="p-0">
            <pre className="p-8 font-mono text-sm text-primary/80 bg-black/40 overflow-x-auto leading-relaxed">
              {sdkCode}
            </pre>
            <div className="p-6 bg-zinc-950/50 border-t border-white/5 text-zinc-500">
               <p className="text-xs">Ideal para aplicativos customizados que precisam manipular os dados estruturados do Atlas RAG.</p>
            </div>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}

function IntegrationType({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) {
  return (
    <div className="p-6 rounded-3xl bg-zinc-900/30 border border-white/5 space-y-3">
      <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
        <Icon className="w-5 h-5" />
      </div>
      <h3 className="font-bold text-white">{title}</h3>
      <p className="text-xs text-zinc-500 leading-relaxed">{desc}</p>
    </div>
  );
}
