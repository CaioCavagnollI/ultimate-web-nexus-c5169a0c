import { Smartphone, Code, Terminal, SmartphoneIcon as ExpoIcon } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function MobilePlan() {
  return (
    <div className="max-w-3xl mx-auto space-y-12">
      <div className="space-y-4">
        <h1 className="text-4xl font-bold tracking-tight">Mobile Integration Plan</h1>
        <p className="text-zinc-400 text-lg">Transitioning from PWA to Native with React Native & Expo.</p>
      </div>

      <div className="grid gap-6">
        <Section 
          icon={Smartphone}
          title="Native Capabilities" 
          desc="Access low-level Camera APIs for faster scanning and offline model inference using TensorFlow.js for React Native."
        />
        <Section 
          icon={Code}
          title="Component Strategy" 
          desc="Shared UI logic between Web and Mobile using React Native Web or dedicated styled-components for cross-platform consistency."
        />
        <Section 
          icon={Terminal}
          title="API Interface" 
          desc="Unified Scanner endpoints serving structured JSON (equipment_id, confidence, compatible_protocols)."
        />
      </div>

      <Card className="p-8 bg-zinc-900 border-white/5 space-y-6">
        <div className="flex items-center gap-4">
           <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
             <ExpoIcon className="w-6 h-6 text-primary" />
           </div>
           <div>
             <h3 className="text-xl font-bold">Expo Roadmap</h3>
             <p className="text-sm text-zinc-500">Proposed directory structure</p>
           </div>
        </div>

        <pre className="bg-black/50 p-6 rounded-xl border border-white/5 font-mono text-xs text-zinc-400 overflow-x-auto">
{`mobile/
├── assets/         # App icons & splash
├── src/
│   ├── api/        # Shared fetch logic
│   ├── components/ # Atomic UI elements
│   ├── hooks/      # useScanner, useProtocols
│   ├── screens/    # ScannerView, LibraryView
│   └── theme/      # Spacing & Color tokens
├── App.js          # Navigation entry
└── app.json        # Expo config`}
        </pre>
      </Card>
    </div>
  );
}

function Section({ icon: Icon, title, desc }: { icon: any, title: string, desc: string }) {
  return (
    <div className="flex gap-6 p-6 rounded-3xl bg-zinc-900/30 border border-white/5">
      <div className="w-12 h-12 shrink-0 rounded-2xl bg-primary/10 flex items-center justify-center text-primary">
        <Icon className="w-6 h-6" />
      </div>
      <div>
        <h3 className="text-xl font-bold mb-2">{title}</h3>
        <p className="text-zinc-400 leading-relaxed text-sm">{desc}</p>
      </div>
    </div>
  )
}
