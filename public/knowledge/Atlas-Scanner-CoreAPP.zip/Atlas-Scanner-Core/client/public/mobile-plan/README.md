# AtlasLab Mobile Implementation Plan

## Overview
This document outlines the strategy for porting the AtlasLab PWA to a native mobile application using React Native (Expo).

## Architecture
- **Framework**: Expo (Managed Workflow)
- **Language**: TypeScript
- **State Management**: React Query (TanStack Query) - Shared logic with Web
- **UI Library**: NativeWind (Tailwind for RN) + Reusable primitives

## Shared Core
The following logic should be extracted to a shared package or monorepo structure:
1. `client/src/lib/mock-data.ts` (Data Models)
2. `client/src/lib/scanner-engine.ts` (Business Logic)
3. API Client / Query Hooks

## Native Specifics

### 1. Camera & Vision
Replace `react-webcam` with `expo-camera`.
```typescript
import { Camera } from 'expo-camera';
// ...
<Camera style={StyleSheet.absoluteFill} type={type} />
```

### 2. Navigation
Replace `wouter` with `expo-router` (file-based routing similar to Next.js).
- `app/_layout.tsx` -> Main Stack
- `app/(tabs)/_layout.tsx` -> Bottom Tabs (Scanner, Library, Admin)

### 3. Haptics
Use `expo-haptics` for tactile feedback during scanning and success states.

### 4. Performance
- Use `FlashList` for the Exercise Catalog.
- Optimize image processing by resizing on the native side before sending to the "Vision Engine" (Stub).

## Roadmap
1. **Phase 1**: Init Expo project, setup NativeWind.
2. **Phase 2**: Port `scanner-engine.ts` and ensure mock logic works.
3. **Phase 3**: Build Camera screen with overlay.
4. **Phase 4**: Port Catalog and Admin screens.
5. **Phase 5**: Add Offline Persistence (SQLite / MMKV).
