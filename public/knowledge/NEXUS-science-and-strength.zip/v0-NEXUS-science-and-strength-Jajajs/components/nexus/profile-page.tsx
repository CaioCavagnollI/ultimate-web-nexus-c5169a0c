"use client"

import { Settings, BookOpen, Dumbbell, Award, Bell, LogOut, ChevronRight, Crown, Calendar, Flame, Target } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

const userStats = {
  workoutsThisWeek: 4,
  workoutsGoal: 5,
  streak: 12,
  booksOwned: 3,
  totalWorkouts: 156
}

const menuItems = [
  { icon: Dumbbell, label: "Meus Treinos", description: "Histórico e prescrições", badge: "12 treinos" },
  { icon: BookOpen, label: "Biblioteca", description: "Seus livros e cursos", badge: "3 itens" },
  { icon: Award, label: "Certificações", description: "Badges e conquistas" },
  { icon: Calendar, label: "Agenda", description: "Consultorias agendadas" },
  { icon: Bell, label: "Notificações", description: "Preferências de alertas" },
  { icon: Settings, label: "Configurações", description: "Conta e privacidade" },
]

export function ProfilePage() {
  return (
    <div className="min-h-screen">
      {/* Profile Header */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center gap-6">
          <Avatar className="w-24 h-24 md:w-32 md:h-32 border-4 border-primary/20">
            <AvatarImage src="/placeholder-user.jpg" alt="User" />
            <AvatarFallback className="bg-primary/20 text-primary text-2xl">US</AvatarFallback>
          </Avatar>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <h1 className="text-2xl md:text-3xl font-bold">Usuário Nexus</h1>
              <Badge className="bg-accent/10 text-accent border-accent/20">
                <Crown className="w-3 h-3 mr-1" />
                Premium
              </Badge>
            </div>
            <p className="text-muted-foreground mb-4">usuario@email.com</p>
            <div className="flex gap-3">
              <Button variant="outline" size="sm" className="border-border hover:bg-secondary bg-transparent">
                <Settings className="w-4 h-4 mr-2" />
                Editar Perfil
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Cards */}
      <section className="container mx-auto px-4 pb-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Flame className="w-6 h-6 text-orange-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">{userStats.streak}</div>
              <div className="text-xs text-muted-foreground">Dias seguidos</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Dumbbell className="w-6 h-6 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">{userStats.totalWorkouts}</div>
              <div className="text-xs text-muted-foreground">Total treinos</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <BookOpen className="w-6 h-6 text-accent mx-auto mb-2" />
              <div className="text-2xl font-bold">{userStats.booksOwned}</div>
              <div className="text-xs text-muted-foreground">Livros</div>
            </CardContent>
          </Card>
          
          <Card className="bg-card border-border">
            <CardContent className="p-4 text-center">
              <Award className="w-6 h-6 text-green-500 mx-auto mb-2" />
              <div className="text-2xl font-bold">7</div>
              <div className="text-xs text-muted-foreground">Conquistas</div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Weekly Progress */}
      <section className="container mx-auto px-4 pb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                <span className="font-semibold">Meta Semanal</span>
              </div>
              <span className="text-sm text-muted-foreground">
                {userStats.workoutsThisWeek}/{userStats.workoutsGoal} treinos
              </span>
            </div>
            <Progress 
              value={(userStats.workoutsThisWeek / userStats.workoutsGoal) * 100} 
              className="h-3 bg-secondary"
            />
            <p className="text-xs text-muted-foreground mt-2">
              Faltam {userStats.workoutsGoal - userStats.workoutsThisWeek} treinos para completar sua meta!
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Menu Items */}
      <section className="container mx-auto px-4 pb-6">
        <div className="space-y-2">
          {menuItems.map((item) => (
            <Card key={item.label} className="bg-card border-border hover:border-primary/30 transition-colors cursor-pointer">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <item.icon className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h3 className="font-medium">{item.label}</h3>
                      {item.badge && (
                        <Badge variant="secondary" className="text-xs">
                          {item.badge}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">{item.description}</p>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Logout */}
      <section className="container mx-auto px-4 pb-24 md:pb-8">
        <Button 
          variant="outline" 
          className="w-full border-destructive/30 text-destructive hover:bg-destructive/10 hover:text-destructive bg-transparent"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair da Conta
        </Button>
      </section>
    </div>
  )
}
