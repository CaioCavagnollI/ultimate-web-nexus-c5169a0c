"use client"

import React from "react"

import { useState, useRef, useEffect } from "react"
import { Send, Bot, User, Sparkles, BookOpen, Dumbbell, Apple, Brain, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { useChat } from "@ai-sdk/react"
import { DefaultChatTransport } from "ai"

const quickActions = [
  { icon: Dumbbell, label: "Periodização", prompt: "Explique os princípios da periodização ondulada" },
  { icon: Apple, label: "Nutrição", prompt: "Qual a importância da proteína para hipertrofia?" },
  { icon: Brain, label: "Recuperação", prompt: "Como otimizar a recuperação entre treinos?" },
  { icon: BookOpen, label: "Biomecânica", prompt: "Qual a biomecânica correta do supino?" },
]

function getMessageText(message: { parts?: Array<{ type: string; text?: string }> }): string {
  if (!message.parts || !Array.isArray(message.parts)) return ""
  return message.parts
    .filter((p): p is { type: "text"; text: string } => p.type === "text" && typeof p.text === "string")
    .map((p) => p.text)
    .join("")
}

export function AIMentorPage() {
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).slice(2)}`)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const [inputValue, setInputValue] = useState("")

  const { messages, sendMessage, status } = useChat({
    transport: new DefaultChatTransport({
      api: "/api/chat",
      prepareSendMessagesRequest: ({ id, messages }) => ({
        body: {
          messages,
          sessionId,
          id,
        },
      }),
    }),
  })

  const isLoading = status === "streaming" || status === "submitted"

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const handleSend = async (text?: string) => {
    const messageText = text || inputValue
    if (!messageText.trim() || isLoading) return
    
    setInputValue("")
    await sendMessage({ text: messageText })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSend()
  }

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 md:top-16 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
              <Bot className="w-5 h-5 text-cyan-500" />
            </div>
            <div>
              <h1 className="font-bold flex items-center gap-2 text-foreground">
                Nexus AI Mentor
                <Badge className="bg-cyan-500/10 text-cyan-500 border-cyan-500/20 text-xs">
                  <Sparkles className="w-3 h-3 mr-1" />
                  RAG
                </Badge>
              </h1>
              <p className="text-sm text-muted-foreground">Treinada com os livros de Caio Cavagnolli</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions - shown when no messages */}
      {messages.length === 0 && (
        <div className="container mx-auto px-4 py-6">
          <div className="text-center mb-6">
            <div className="w-16 h-16 rounded-full bg-cyan-500/20 flex items-center justify-center mx-auto mb-4">
              <Bot className="w-8 h-8 text-cyan-500" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Olá! Sou a Nexus AI</h2>
            <p className="text-muted-foreground text-sm max-w-md mx-auto">
              Fui treinada com os livros de Caio Cavagnolli sobre treinamento de força, periodização, biomecânica e nutrição esportiva.
            </p>
          </div>
          <p className="text-sm text-muted-foreground mb-4 text-center">Sugestões para começar:</p>
          <div className="grid grid-cols-2 gap-3 max-w-lg mx-auto">
            {quickActions.map((action) => (
              <button
                type="button"
                key={action.label}
                onClick={() => handleSend(action.prompt)}
                disabled={isLoading}
                className="p-4 rounded-lg bg-card border border-border hover:border-cyan-500/50 transition-colors text-left disabled:opacity-50"
              >
                <action.icon className="w-5 h-5 text-cyan-500 mb-2" />
                <p className="font-medium text-sm text-foreground">{action.label}</p>
                <p className="text-xs text-muted-foreground line-clamp-1">{action.prompt}</p>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Messages */}
      <div className="flex-1 container mx-auto px-4 py-4 space-y-4 overflow-y-auto">
        {messages.map((message) => {
          const text = getMessageText(message)
          if (!text) return null
          
          return (
            <div
              key={message.id}
              className={cn(
                "flex gap-3",
                message.role === "user" ? "justify-end" : "justify-start"
              )}
            >
              {message.role === "assistant" && (
                <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-cyan-500" />
                </div>
              )}
              <Card className={cn(
                "max-w-[85%] md:max-w-[70%]",
                message.role === "user" 
                  ? "bg-cyan-600 text-white" 
                  : "bg-card"
              )}>
                <CardContent className="p-3 md:p-4">
                  <p className={cn(
                    "text-sm whitespace-pre-line leading-relaxed",
                    message.role === "user" ? "text-white" : "text-foreground"
                  )}>
                    {text}
                  </p>
                  {message.role === "assistant" && (
                    <div className="mt-3 pt-3 border-t border-border/50">
                      <p className="text-xs text-muted-foreground flex items-center gap-1">
                        <BookOpen className="w-3 h-3" />
                        Fonte: Livros Caio Cavagnolli
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
              {message.role === "user" && (
                <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          )
        })}
        
        {isLoading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-cyan-500/20 flex items-center justify-center shrink-0">
              <Bot className="w-4 h-4 text-cyan-500" />
            </div>
            <Card className="bg-card">
              <CardContent className="p-4">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-cyan-500" />
                  <span className="text-sm text-muted-foreground">Pensando...</span>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-border bg-card/95 backdrop-blur-sm sticky bottom-16 md:bottom-0">
        <div className="container mx-auto px-4 py-4">
          <form onSubmit={handleSubmit} className="flex gap-3">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              placeholder="Pergunte sobre treino, nutrição, periodização..."
              className="flex-1 bg-secondary border border-border rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-500/50 placeholder:text-muted-foreground text-foreground"
              disabled={isLoading}
            />
            <Button 
              type="submit" 
              size="icon" 
              className="h-12 w-12 bg-cyan-600 hover:bg-cyan-700"
              disabled={!inputValue.trim() || isLoading}
            >
              <Send className="w-5 h-5" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
