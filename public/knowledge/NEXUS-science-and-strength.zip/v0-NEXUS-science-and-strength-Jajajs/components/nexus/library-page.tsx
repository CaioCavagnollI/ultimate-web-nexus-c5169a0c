"use client"

import { useState } from "react"
import { Lock, Star, ShoppingCart, BookOpen, FileText, Gift, ChevronRight, Sparkles, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import useSWR from "swr"
import { createClient } from "@/lib/supabase/client"
import { BookDetail } from "./book-detail"
import { Checkout } from "@/components/checkout"

interface Book {
  id: string
  title: string
  subtitle: string | null
  description: string | null
  author: string
  cover_url: string | null
  price: number
  original_price: number | null
  category: string | null
  is_featured: boolean
  is_bundle: boolean
  bundle_books: string[] | null
}

const fetcher = async () => {
  const supabase = createClient()
  const { data, error } = await supabase
    .from("books")
    .select("*")
    .order("is_featured", { ascending: false })
    .order("created_at", { ascending: false })
  
  if (error) throw error
  return data as Book[]
}

const categoryColors: Record<string, string> = {
  "Coleção": "bg-gradient-to-br from-cyan-600 to-cyan-800",
  "Treinamento": "bg-gradient-to-br from-blue-600 to-blue-800",
  "Biomecânica": "bg-gradient-to-br from-green-600 to-green-800",
  "Força": "bg-gradient-to-br from-red-600 to-red-800",
  "Nutrição": "bg-gradient-to-br from-orange-600 to-orange-800",
  "Recuperação": "bg-gradient-to-br from-purple-600 to-purple-800",
  "Psicologia": "bg-gradient-to-br from-pink-600 to-pink-800",
}

export function LibraryPage() {
  const { data: books, isLoading, error } = useSWR("books", fetcher)
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null)
  const [showBundleCheckout, setShowBundleCheckout] = useState(false)

  const featuredBundle = books?.find(b => b.is_featured && b.is_bundle)
  const regularBooks = books?.filter(b => !b.is_bundle) || []

  // Show book detail page
  if (selectedBookId) {
    return <BookDetail bookId={selectedBookId} onBack={() => setSelectedBookId(null)} />
  }

  // Show bundle checkout
  if (showBundleCheckout && featuredBundle) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Button variant="ghost" onClick={() => setShowBundleCheckout(false)} className="gap-2 mb-4">
          <ChevronRight className="h-4 w-4 rotate-180" />
          Voltar
        </Button>
        <Checkout productId="box-cavagnolli" />
      </div>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-500" />
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-red-500">Erro ao carregar livros</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-2">
          <BookOpen className="w-6 h-6 text-cyan-500" />
          <h1 className="text-2xl md:text-3xl font-bold text-foreground">Nexus Publishing</h1>
        </div>
        <p className="text-muted-foreground">Livros e conteúdos científicos de alta qualidade</p>
      </section>

      {/* Featured Box */}
      {featuredBundle && (
        <section className="container mx-auto px-4 pb-8">
          <Card className="bg-gradient-to-br from-cyan-500/10 via-card to-card border-cyan-500/30 overflow-hidden relative">
            <div className="absolute top-4 right-4">
              {featuredBundle.original_price && (
                <Badge className="bg-cyan-500 text-white">
                  -{Math.round(100 - (featuredBundle.price / featuredBundle.original_price) * 100)}% OFF
                </Badge>
              )}
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                <span className="text-sm font-medium text-yellow-500">Best-Seller</span>
              </div>
              
              <h2 className="text-2xl md:text-3xl font-bold mb-2 text-foreground">{featuredBundle.title}</h2>
              <p className="text-muted-foreground mb-6">{featuredBundle.subtitle}</p>

              {/* Bundle Books List */}
              {featuredBundle.bundle_books && (
                <div className="mb-6 grid grid-cols-1 md:grid-cols-3 gap-2">
                  {featuredBundle.bundle_books.slice(0, 6).map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <BookOpen className="w-3 h-3 text-cyan-500 shrink-0" />
                      <span className="truncate">{item}</span>
                    </div>
                  ))}
                </div>
              )}
              
              {featuredBundle.bundle_books && featuredBundle.bundle_books.length > 6 && (
                <p className="text-sm text-muted-foreground mb-6">
                  + {featuredBundle.bundle_books.length - 6} mais livros inclusos
                </p>
              )}

              {/* Description */}
              {featuredBundle.description && (
                <p className="text-sm text-muted-foreground mb-6">{featuredBundle.description}</p>
              )}

              {/* Pricing */}
              <div className="flex items-end gap-3 mb-6">
                {featuredBundle.original_price && (
                  <span className="text-sm text-muted-foreground line-through">
                    R$ {featuredBundle.original_price.toFixed(2)}
                  </span>
                )}
                <span className="text-3xl md:text-4xl font-bold text-cyan-500">
                  R$ {featuredBundle.price.toFixed(2)}
                </span>
              </div>

              <Button size="lg" className="w-full bg-cyan-600 hover:bg-cyan-700 text-white" onClick={() => setShowBundleCheckout(true)}>
                <Lock className="w-4 h-4 mr-2" />
                Comprar Agora
              </Button>
            </CardContent>
          </Card>
        </section>
      )}

      {/* Books Grid */}
      <section className="container mx-auto px-4 pb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-foreground">Todos os Livros</h2>
          <Button variant="ghost" size="sm" className="text-cyan-500 hover:text-cyan-400">
            Filtrar
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {regularBooks.map((book) => (
            <Card key={book.id} className="bg-card border-border overflow-hidden group cursor-pointer" onClick={() => setSelectedBookId(book.id)}>
              <div className={`aspect-[3/4] ${categoryColors[book.category || "Treinamento"] || "bg-gradient-to-br from-slate-600 to-slate-800"} flex items-center justify-center relative`}>
                <div className="absolute inset-0 bg-black/20" />
                <div className="text-center p-4 relative z-10">
                  <BookOpen className="w-10 h-10 text-white/80 mx-auto mb-2" />
                  <h3 className="text-white font-bold text-sm md:text-base leading-tight">{book.title}</h3>
                  {book.subtitle && (
                    <p className="text-white/70 text-xs mt-1 line-clamp-2">{book.subtitle}</p>
                  )}
                </div>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Button size="sm" className="bg-white text-black hover:bg-white/90">
                    <ShoppingCart className="w-4 h-4 mr-1" />
                    Ver Detalhes
                  </Button>
                </div>
              </div>
              <CardContent className="p-3">
                <Badge variant="outline" className="text-xs mb-2 border-cyan-500/30 text-cyan-500">
                  {book.category || "Treinamento"}
                </Badge>
                <p className="text-xs text-muted-foreground mb-1">{book.author}</p>
                <p className="font-bold text-cyan-500">R$ {book.price.toFixed(2)}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {regularBooks.length === 0 && (
          <div className="text-center py-12">
            <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">Nenhum livro disponível ainda</p>
          </div>
        )}
      </section>

      {/* Publish CTA */}
      <section className="container mx-auto px-4 pb-24 md:pb-8">
        <Card className="bg-gradient-to-br from-cyan-500/10 via-card to-card border-cyan-500/30">
          <CardContent className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:items-center gap-6">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-cyan-500" />
                  <span className="text-sm font-medium text-cyan-500">Para Autores</span>
                </div>
                <h2 className="text-2xl md:text-3xl font-bold mb-3 text-foreground">Publique sua Obra no Nexus</h2>
                <p className="text-muted-foreground mb-4">
                  Receba <span className="text-cyan-500 font-semibold">90% dos royalties</span>. 
                  Submeta seu livro acadêmico e faça parte da maior plataforma de conteúdo científico sobre treino.
                </p>
                <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                  <div className="flex items-center gap-2">
                    <FileText className="w-4 h-4 text-cyan-500" />
                    <span>Revisão profissional</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Gift className="w-4 h-4 text-cyan-500" />
                    <span>Marketing incluso</span>
                  </div>
                </div>
              </div>
              <div className="md:shrink-0">
                <Button size="lg" className="w-full md:w-auto bg-cyan-600 hover:bg-cyan-700 text-white">
                  <FileText className="w-4 h-4 mr-2" />
                  Enviar Manuscrito
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
