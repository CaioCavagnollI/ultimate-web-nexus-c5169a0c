"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Textarea } from "@/components/ui/textarea"
import {
  ArrowLeft,
  Star,
  BookOpen,
  ShoppingCart,
  Clock,
  Users,
  CheckCircle2,
  MessageSquare,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { Checkout } from "@/components/checkout"

interface Book {
  id: string
  title: string
  description: string | null
  author: string
  price: number
  cover_image_url: string | null
  category: string
  pages: number | null
  is_published: boolean
}

interface Review {
  id: string
  rating: number
  comment: string | null
  created_at: string
  user_id: string
}

interface ReadingProgress {
  current_page: number
  total_pages: number
  last_read_at: string
}

interface BookDetailProps {
  bookId: string
  onBack: () => void
}

export function BookDetail({ bookId, onBack }: BookDetailProps) {
  const [book, setBook] = useState<Book | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [readingProgress, setReadingProgress] = useState<ReadingProgress | null>(null)
  const [showCheckout, setShowCheckout] = useState(false)
  const [newReview, setNewReview] = useState({ rating: 5, comment: "" })
  const [submittingReview, setSubmittingReview] = useState(false)
  const [hasPurchased, setHasPurchased] = useState(false)
  const supabase = createClient()

  useEffect(() => {
    async function loadBook() {
      const { data } = await supabase
        .from("books")
        .select("*")
        .eq("id", bookId)
        .single()
      
      if (data) setBook(data)
    }

    async function loadReviews() {
      const { data } = await supabase
        .from("reviews")
        .select("*")
        .eq("book_id", bookId)
        .order("created_at", { ascending: false })
      
      if (data) setReviews(data)
    }

    loadBook()
    loadReviews()
  }, [bookId, supabase])

  const averageRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0

  const handleSubmitReview = async () => {
    setSubmittingReview(true)
    
    const { error } = await supabase.from("reviews").insert({
      book_id: bookId,
      user_id: "anonymous",
      rating: newReview.rating,
      comment: newReview.comment || null,
    })
    
    if (!error) {
      const { data } = await supabase
        .from("reviews")
        .select("*")
        .eq("book_id", bookId)
        .order("created_at", { ascending: false })
      
      if (data) setReviews(data)
      setNewReview({ rating: 5, comment: "" })
    }
    
    setSubmittingReview(false)
  }

  if (!book) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-pulse text-muted-foreground">Carregando...</div>
      </div>
    )
  }

  if (showCheckout) {
    return (
      <div className="space-y-4">
        <Button variant="ghost" onClick={() => setShowCheckout(false)} className="gap-2">
          <ArrowLeft className="h-4 w-4" />
          Voltar
        </Button>
        <Checkout productId={`book-${book.id}`} />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Button variant="ghost" onClick={onBack} className="gap-2 -ml-2">
        <ArrowLeft className="h-4 w-4" />
        Voltar para Biblioteca
      </Button>

      {/* Book Info */}
      <div className="grid md:grid-cols-3 gap-6">
        {/* Cover */}
        <div className="md:col-span-1">
          <div className="aspect-[3/4] rounded-lg bg-gradient-to-br from-cyan-500/20 to-cyan-600/10 border border-cyan-500/20 flex items-center justify-center">
            <BookOpen className="h-20 w-20 text-cyan-500/50" />
          </div>
        </div>

        {/* Details */}
        <div className="md:col-span-2 space-y-4">
          <div>
            <Badge variant="secondary" className="mb-2 bg-cyan-500/10 text-cyan-400 border-cyan-500/20">
              {book.category}
            </Badge>
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">{book.title}</h1>
            <p className="text-muted-foreground mt-1">por {book.author}</p>
          </div>

          {/* Rating */}
          <div className="flex items-center gap-2">
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`h-5 w-5 ${
                    star <= Math.round(averageRating)
                      ? "fill-yellow-500 text-yellow-500"
                      : "text-muted-foreground/30"
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {averageRating.toFixed(1)} ({reviews.length} avaliações)
            </span>
          </div>

          {/* Stats */}
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            {book.pages && (
              <div className="flex items-center gap-1">
                <BookOpen className="h-4 w-4" />
                {book.pages} páginas
              </div>
            )}
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              ~{Math.round((book.pages || 200) / 30)}h de leitura
            </div>
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {Math.floor(Math.random() * 500) + 100} leitores
            </div>
          </div>

          <p className="text-muted-foreground leading-relaxed">
            {book.description}
          </p>

          {/* Price & CTA */}
          <Card className="p-4 bg-card/50 border-border/50">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-3xl font-bold text-foreground">
                  R$ {book.price?.toFixed(2).replace(".", ",")}
                </div>
                <p className="text-xs text-muted-foreground">ou 12x de R$ {(book.price / 12).toFixed(2).replace(".", ",")}</p>
              </div>
              <Button 
                size="lg" 
                onClick={() => setShowCheckout(true)}
                className="gap-2 bg-cyan-600 hover:bg-cyan-700 text-white"
              >
                <ShoppingCart className="h-5 w-5" />
                Comprar Agora
              </Button>
            </div>
          </Card>

          {/* Reading Progress (if purchased) */}
          {readingProgress && (
            <Card className="p-4 bg-card/50 border-border/50">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-foreground">Seu progresso</span>
                <span className="text-sm text-muted-foreground">
                  {readingProgress.current_page}/{readingProgress.total_pages} páginas
                </span>
              </div>
              <Progress 
                value={(readingProgress.current_page / readingProgress.total_pages) * 100} 
                className="h-2"
              />
            </Card>
          )}
        </div>
      </div>

      <Separator className="bg-border/50" />

      {/* Reviews Section */}
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-cyan-500" />
          Avaliações
        </h2>

        {/* Write Review */}
        <Card className="p-4 bg-card/50 border-border/50 space-y-3">
          <h3 className="font-medium text-foreground">Deixe sua avaliação</h3>
          <div className="flex gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                onClick={() => setNewReview({ ...newReview, rating: star })}
                className="p-1 transition-transform hover:scale-110"
              >
                <Star
                  className={`h-6 w-6 ${
                    star <= newReview.rating
                      ? "fill-yellow-500 text-yellow-500"
                      : "text-muted-foreground/30"
                  }`}
                />
              </button>
            ))}
          </div>
          <Textarea
            placeholder="Conte o que achou do livro..."
            value={newReview.comment}
            onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
            className="bg-background/50 border-border/50"
          />
          <Button 
            onClick={handleSubmitReview} 
            disabled={submittingReview}
            className="bg-cyan-600 hover:bg-cyan-700 text-white"
          >
            {submittingReview ? "Enviando..." : "Enviar Avaliação"}
          </Button>
        </Card>

        {/* Reviews List */}
        <div className="space-y-3">
          {reviews.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">
              Nenhuma avaliação ainda. Seja o primeiro a avaliar!
            </p>
          ) : (
            reviews.map((review) => (
              <Card key={review.id} className="p-4 bg-card/50 border-border/50">
                <div className="flex items-center gap-2 mb-2">
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-4 w-4 ${
                          star <= review.rating
                            ? "fill-yellow-500 text-yellow-500"
                            : "text-muted-foreground/30"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    {new Date(review.created_at).toLocaleDateString("pt-BR")}
                  </span>
                </div>
                {review.comment && (
                  <p className="text-sm text-foreground">{review.comment}</p>
                )}
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
