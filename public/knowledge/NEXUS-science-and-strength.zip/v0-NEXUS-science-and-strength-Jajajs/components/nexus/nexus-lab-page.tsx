"use client"

import { Crown, Star, Check, Users, Award, Zap, MessageCircle, Lock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const vipPlan = {
  title: "Consultoria Cavagnolli Black",
  price: 497,
  period: "mês",
  features: [
    "Mentoria direta com o autor",
    "Acesso a todos os livros",
    "Treinos personalizados mensais",
    "Avaliação física completa",
    "Grupo VIP exclusivo",
    "Suporte prioritário 24/7"
  ]
}

const trainers = [
  {
    id: 1,
    name: "João Silva",
    specialty: "Força e Powerlifting",
    rating: 4.9,
    reviews: 127,
    price: 197,
    image: "/placeholder-user.jpg",
    certifications: ["CREF", "Nexus Certificado"],
    available: true
  },
  {
    id: 2,
    name: "Maria Santos",
    specialty: "Hipertrofia e Bodybuilding",
    rating: 4.8,
    reviews: 98,
    price: 247,
    image: "/placeholder-user.jpg",
    certifications: ["CREF", "Nexus Certificado", "ISSN"],
    available: true
  },
  {
    id: 3,
    name: "Pedro Costa",
    specialty: "Performance Atlética",
    rating: 4.7,
    reviews: 64,
    price: 177,
    image: "/placeholder-user.jpg",
    certifications: ["CREF", "Nexus Certificado"],
    available: false
  },
]

export function NexusLabPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-2">
          <Users className="w-6 h-6 text-primary" />
          <h1 className="text-2xl md:text-3xl font-bold">Nexus Lab</h1>
        </div>
        <p className="text-muted-foreground">Consultoria e treinamento com profissionais certificados</p>
      </section>

      {/* VIP Plan */}
      <section className="container mx-auto px-4 pb-8">
        <Card className="bg-gradient-to-br from-accent/20 via-accent/10 to-card border-accent/40 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-32 h-32 bg-accent/10 rounded-full blur-3xl" />
          <div className="absolute bottom-0 left-0 w-24 h-24 bg-accent/5 rounded-full blur-2xl" />
          
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Badge className="bg-accent text-accent-foreground">
                <Crown className="w-3 h-3 mr-1" />
                VIP
              </Badge>
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 text-accent fill-accent" />
                ))}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="relative">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">{vipPlan.title}</h2>
            <div className="flex items-baseline gap-1 mb-6">
              <span className="text-4xl md:text-5xl font-bold text-accent">R$ {vipPlan.price}</span>
              <span className="text-muted-foreground">/{vipPlan.period}</span>
            </div>

            <div className="grid gap-3 mb-6">
              {vipPlan.features.map((feature, idx) => (
                <div key={idx} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-accent/20 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 text-accent" />
                  </div>
                  <span className="text-sm">{feature}</span>
                </div>
              ))}
            </div>

            <Button size="lg" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
              <Lock className="w-4 h-4 mr-2" />
              Assinar Plano VIP
            </Button>
          </CardContent>
        </Card>
      </section>

      {/* Trainers Marketplace */}
      <section className="container mx-auto px-4 pb-8">
        <h2 className="text-xl font-bold mb-6">Treinadores Certificados</h2>
        
        <div className="space-y-4">
          {trainers.map((trainer) => (
            <Card key={trainer.id} className="bg-card border-border overflow-hidden">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <Avatar className="w-16 h-16 md:w-20 md:h-20">
                    <AvatarImage src={trainer.image || "/placeholder.svg"} alt={trainer.name} />
                    <AvatarFallback className="bg-primary/20 text-primary text-lg">
                      {trainer.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div>
                        <h3 className="font-semibold text-lg">{trainer.name}</h3>
                        <p className="text-sm text-muted-foreground">{trainer.specialty}</p>
                      </div>
                      <Badge 
                        variant={trainer.available ? "default" : "secondary"}
                        className={trainer.available ? "bg-green-500/10 text-green-500 border-green-500/20" : ""}
                      >
                        {trainer.available ? "Disponível" : "Lotado"}
                      </Badge>
                    </div>

                    <div className="flex items-center gap-4 mb-3">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-accent fill-accent" />
                        <span className="text-sm font-medium">{trainer.rating}</span>
                        <span className="text-xs text-muted-foreground">({trainer.reviews})</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {trainer.certifications.map((cert, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs border-primary/30 text-primary">
                          <Award className="w-3 h-3 mr-1" />
                          {cert}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <span className="text-2xl font-bold text-primary">R$ {trainer.price}</span>
                        <span className="text-sm text-muted-foreground">/mês</span>
                      </div>
                      <Button 
                        disabled={!trainer.available}
                        className={trainer.available ? "bg-primary hover:bg-primary/90" : ""}
                      >
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Contratar
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA for Professionals */}
      <section className="container mx-auto px-4 pb-24 md:pb-8">
        <Card className="bg-gradient-to-br from-primary/10 via-card to-card border-primary/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-3">
              <Zap className="w-5 h-5 text-primary" />
              <span className="text-sm font-medium text-primary">Para Profissionais</span>
            </div>
            <h2 className="text-xl md:text-2xl font-bold mb-3">É Personal Trainer?</h2>
            <p className="text-muted-foreground mb-6">
              Crie seu Consultório Digital aqui e pague <span className="text-primary font-semibold">apenas se vender</span>. 
              Sem taxas fixas, sem burocracia.
            </p>
            
            <div className="grid grid-cols-3 gap-4 mb-6 text-center">
              <div>
                <div className="text-2xl font-bold text-primary">0%</div>
                <div className="text-xs text-muted-foreground">Taxa fixa</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-accent">85%</div>
                <div className="text-xs text-muted-foreground">Para você</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-primary">24h</div>
                <div className="text-xs text-muted-foreground">Aprovação</div>
              </div>
            </div>

            <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
              Criar Perfil de Treinador
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
