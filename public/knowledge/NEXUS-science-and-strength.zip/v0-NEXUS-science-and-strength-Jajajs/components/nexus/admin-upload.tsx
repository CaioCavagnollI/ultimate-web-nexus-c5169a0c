"use client"

import React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Upload, FileText, Check, Loader2, BookOpen, Plus } from "lucide-react"

interface Book {
  id: string
  title: string
}

export function AdminUpload({ existingBooks }: { existingBooks: Book[] }) {
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [mode, setMode] = useState<"new" | "existing">("new")
  const [selectedBookId, setSelectedBookId] = useState<string>("")
  
  // New book form
  const [title, setTitle] = useState("")
  const [subtitle, setSubtitle] = useState("")
  const [description, setDescription] = useState("")
  const [price, setPrice] = useState("")
  const [category, setCategory] = useState("Treinamento")

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }, [])

  const handleUpload = async () => {
    if (!selectedFile && mode === "existing") {
      alert("Selecione um arquivo para upload")
      return
    }

    if (mode === "new" && !title) {
      alert("Preencha o título do livro")
      return
    }

    setIsUploading(true)
    setUploadSuccess(false)

    try {
      const formData = new FormData()
      
      if (selectedFile) {
        formData.append("file", selectedFile)
      }

      if (mode === "existing" && selectedBookId) {
        formData.append("bookId", selectedBookId)
      } else {
        formData.append("title", title)
        formData.append("subtitle", subtitle)
        formData.append("description", description)
        formData.append("price", price)
        formData.append("category", category)
      }

      const response = await fetch("/api/books/upload", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()

      if (result.success) {
        setUploadSuccess(true)
        setSelectedFile(null)
        if (mode === "new") {
          setTitle("")
          setSubtitle("")
          setDescription("")
          setPrice("")
        }
        
        setTimeout(() => setUploadSuccess(false), 3000)
      } else {
        alert("Erro: " + result.error)
      }
    } catch (error) {
      console.error("Upload error:", error)
      alert("Erro ao fazer upload")
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background p-6">
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-foreground mb-2">Admin - Upload de Livros</h1>
          <p className="text-muted-foreground">
            Adicione novos livros ou conteúdo para alimentar a IA
          </p>
        </div>

        {/* Mode Selection */}
        <div className="flex gap-4 justify-center">
          <Button
            variant={mode === "new" ? "default" : "outline"}
            onClick={() => setMode("new")}
            className={mode === "new" ? "bg-cyan-600 hover:bg-cyan-700" : ""}
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Livro
          </Button>
          <Button
            variant={mode === "existing" ? "default" : "outline"}
            onClick={() => setMode("existing")}
            className={mode === "existing" ? "bg-cyan-600 hover:bg-cyan-700" : ""}
          >
            <BookOpen className="w-4 h-4 mr-2" />
            Adicionar Conteúdo
          </Button>
        </div>

        {mode === "new" ? (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <Plus className="w-5 h-5 text-cyan-500" />
                Criar Novo Livro
              </CardTitle>
              <CardDescription>
                Adicione um novo livro à biblioteca
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Título *</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Ex: Periodização Científica"
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subtitle">Subtítulo</Label>
                <Input
                  id="subtitle"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  placeholder="Ex: Fundamentos e Aplicações Práticas"
                  className="bg-background"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Descrição</Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Descreva o conteúdo do livro..."
                  className="bg-background min-h-[100px]"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="price">Preço (R$)</Label>
                  <Input
                    id="price"
                    type="number"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="127.00"
                    className="bg-background"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="category">Categoria</Label>
                  <Select value={category} onValueChange={setCategory}>
                    <SelectTrigger className="bg-background">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Treinamento">Treinamento</SelectItem>
                      <SelectItem value="Biomecânica">Biomecânica</SelectItem>
                      <SelectItem value="Força">Força</SelectItem>
                      <SelectItem value="Nutrição">Nutrição</SelectItem>
                      <SelectItem value="Recuperação">Recuperação</SelectItem>
                      <SelectItem value="Psicologia">Psicologia</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* File Upload */}
              <div className="space-y-2">
                <Label>Conteúdo do Livro (TXT)</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-cyan-500/50 transition-colors">
                  <input
                    type="file"
                    accept=".txt"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload-new"
                  />
                  <label
                    htmlFor="file-upload-new"
                    className="cursor-pointer flex flex-col items-center gap-2"
                  >
                    {selectedFile ? (
                      <>
                        <FileText className="w-10 h-10 text-cyan-500" />
                        <span className="text-foreground font-medium">{selectedFile.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {(selectedFile.size / 1024).toFixed(1)} KB
                        </span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-10 h-10 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          Clique para selecionar o arquivo TXT
                        </span>
                        <span className="text-xs text-muted-foreground">
                          (Opcional - pode adicionar depois)
                        </span>
                      </>
                    )}
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-border bg-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-foreground">
                <BookOpen className="w-5 h-5 text-cyan-500" />
                Adicionar Conteúdo a Livro Existente
              </CardTitle>
              <CardDescription>
                Faça upload de conteúdo para um livro já cadastrado
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Selecione o Livro</Label>
                <Select value={selectedBookId} onValueChange={setSelectedBookId}>
                  <SelectTrigger className="bg-background">
                    <SelectValue placeholder="Escolha um livro..." />
                  </SelectTrigger>
                  <SelectContent>
                    {existingBooks.map((book) => (
                      <SelectItem key={book.id} value={book.id}>
                        {book.title}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* File Upload */}
              <div className="space-y-2">
                <Label>Arquivo de Conteúdo (TXT) *</Label>
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center hover:border-cyan-500/50 transition-colors">
                  <input
                    type="file"
                    accept=".txt"
                    onChange={handleFileChange}
                    className="hidden"
                    id="file-upload-existing"
                  />
                  <label
                    htmlFor="file-upload-existing"
                    className="cursor-pointer flex flex-col items-center gap-2"
                  >
                    {selectedFile ? (
                      <>
                        <FileText className="w-10 h-10 text-cyan-500" />
                        <span className="text-foreground font-medium">{selectedFile.name}</span>
                        <span className="text-sm text-muted-foreground">
                          {(selectedFile.size / 1024).toFixed(1)} KB
                        </span>
                      </>
                    ) : (
                      <>
                        <Upload className="w-10 h-10 text-muted-foreground" />
                        <span className="text-muted-foreground">
                          Clique para selecionar o arquivo TXT do livro
                        </span>
                      </>
                    )}
                  </label>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Upload Button */}
        <Button
          onClick={handleUpload}
          disabled={isUploading || (mode === "new" && !title) || (mode === "existing" && (!selectedBookId || !selectedFile))}
          className="w-full h-12 bg-cyan-600 hover:bg-cyan-700 text-white font-medium"
        >
          {isUploading ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Processando...
            </>
          ) : uploadSuccess ? (
            <>
              <Check className="w-5 h-5 mr-2" />
              Upload Concluído!
            </>
          ) : (
            <>
              <Upload className="w-5 h-5 mr-2" />
              {mode === "new" ? "Criar Livro" : "Fazer Upload"}
            </>
          )}
        </Button>

        <p className="text-center text-sm text-muted-foreground">
          O conteúdo será processado e dividido em chunks para alimentar o Mentor IA
        </p>
      </div>
    </div>
  )
}
