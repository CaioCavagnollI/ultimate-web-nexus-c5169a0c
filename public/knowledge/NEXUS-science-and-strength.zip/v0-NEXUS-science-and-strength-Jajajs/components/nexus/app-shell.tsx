"use client"

import { useState, type ReactNode } from "react"
import { Home, BookOpen, MessageCircle, Users, User } from "lucide-react"
import { cn } from "@/lib/utils"

type Tab = "home" | "library" | "ai" | "lab" | "profile"

interface AppShellProps {
  children?: ReactNode
  activeTab: Tab
  onTabChange: (tab: Tab) => void
}

const navItems = [
  { id: "home" as Tab, label: "Home", icon: Home },
  { id: "library" as Tab, label: "Library", icon: BookOpen },
  { id: "ai" as Tab, label: "AI Mentor", icon: MessageCircle },
  { id: "lab" as Tab, label: "Nexus Lab", icon: Users },
  { id: "profile" as Tab, label: "Profile", icon: User },
]

export function AppShell({ children, activeTab, onTabChange }: AppShellProps) {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Desktop Header */}
      <header className="hidden md:flex fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="container mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-primary flex items-center justify-center">
              <span className="font-bold text-primary-foreground text-sm">N</span>
            </div>
            <span className="font-bold text-xl">NEXUS</span>
          </div>
          <nav className="flex items-center gap-1">
            {navItems.map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={cn(
                  "px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2",
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                )}
              >
                <item.icon className="w-4 h-4" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 pt-0 md:pt-16 pb-20 md:pb-0">
        {children}
      </main>

      {/* Mobile Bottom Navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-t border-border">
        <div className="flex items-center justify-around h-16 px-2">
          {navItems.map((item) => (
            <button
              type="button"
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "flex flex-col items-center justify-center gap-1 flex-1 py-2 rounded-lg transition-colors",
                activeTab === item.id
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs font-medium">{item.label}</span>
            </button>
          ))}
        </div>
      </nav>
    </div>
  )
}
