"use client"

import { Heart, MessageSquare, Share2, Bookmark, ChevronRight, Trophy, Dumbbell, Flame } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const feedPosts = [
  {
    id: 1,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Mito da Falha Concêntrica",
    content: "A crença de que treinar até a falha concêntrica é necessário para hipertrofia é um dos maiores equívocos da cultura fitness. Estudos mostram que parar 1-3 repetições antes da falha gera adaptações similares com menor fadiga acumulada.",
    likes: 847,
    comments: 56,
    category: "Fisiologia",
    timeAgo: "2h",
  },
  {
    id: 2,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Biomecânica do Agachamento",
    content: "O joelho pode SIM ultrapassar a ponta do pé. A limitação dessa amplitude força compensações na coluna lombar. O que importa é a distribuição da carga entre quadril e joelho.",
    likes: 1203,
    comments: 89,
    category: "Biomecânica",
    timeAgo: "5h",
  },
  {
    id: 3,
    author: "Caio Cavagnolli",
    avatar: "/placeholder-user.jpg",
    role: "Mestre em Desempenho Funcional, UnB",
    title: "Periodização Ondulada",
    content: "A periodização ondulada diária (DUP) permite variação de intensidade e volume dentro da mesma semana, otimizando as adaptações neurais e estruturais sem gerar monotonia no treinamento.",
    likes: 634,
    comments: 42,
    category: "Periodização",
    timeAgo: "8h",
  },
]

const ambassadors = [
  { id: 1, name: "João Silva", specialty: "Força", image: "/placeholder-user.jpg" },
  { id: 2, name: "Maria Santos", specialty: "Hipertrofia", image: "/placeholder-user.jpg" },
  { id: 3, name: "Pedro Costa", specialty: "Performance", image: "/placeholder-user.jpg" },
]

export function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-background to-background" />
        <div className="container mx-auto px-4 py-12 md:py-20 relative">
          <div className="max-w-3xl mx-auto text-center">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
              <Flame className="w-3 h-3 mr-1" />
              Metodologia Científica
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 text-balance">
              Science Applied to{" "}
              <span className="text-primary">Strength</span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground mb-8 text-pretty">
              A metodologia do Best-Seller Caio Cavagnolli. Treinamento baseado em evidências científicas.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Dumbbell className="w-5 h-5 mr-2" />
                Começar Agora
              </Button>
              <Button size="lg" variant="outline" className="border-border hover:bg-secondary bg-transparent">
                Conhecer Metodologia
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="border-y border-border bg-card/50">
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl md:text-3xl font-bold text-primary">9</div>
              <div className="text-sm text-muted-foreground">Livros Publicados</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-accent">50K+</div>
              <div className="text-sm text-muted-foreground">Alunos</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-bold text-primary">15+</div>
              <div className="text-sm text-muted-foreground">Anos de Pesquisa</div>
            </div>
          </div>
        </div>
      </section>

      {/* Feed Section */}
      <section className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl md:text-2xl font-bold">Conteúdo Científico</h2>
          <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">
            Ver todos
            <ChevronRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
        
        <div className="space-y-4">
          {feedPosts.map((post) => (
            <Card key={post.id} className="bg-card border-border overflow-hidden">
              <CardContent className="p-4 md:p-6">
                {/* Author Header */}
                <div className="flex items-start gap-3 mb-4">
                  <Avatar className="w-10 h-10 md:w-12 md:h-12">
                    <AvatarImage src={post.avatar || "/placeholder.svg"} alt={post.author} />
                    <AvatarFallback className="bg-primary/20 text-primary">
                      {post.author.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="font-semibold text-foreground">{post.author}</h3>
                      <Badge variant="secondary" className="text-xs bg-accent/10 text-accent border-accent/20">
                        Autor
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{post.role}</p>
                  </div>
                  <span className="text-xs text-muted-foreground">{post.timeAgo}</span>
                </div>

                {/* Content */}
                <div className="mb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className="text-xs border-primary/30 text-primary">
                      {post.category}
                    </Badge>
                  </div>
                  <h4 className="font-semibold text-lg mb-2">{post.title}</h4>
                  <p className="text-muted-foreground leading-relaxed">{post.content}</p>
                </div>

                {/* Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-border">
                  <div className="flex items-center gap-4">
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Heart className="w-5 h-5" />
                      <span className="text-sm">{post.likes}</span>
                    </button>
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <MessageSquare className="w-5 h-5" />
                      <span className="text-sm">{post.comments}</span>
                    </button>
                    <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-primary transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                  <button type="button" className="text-muted-foreground hover:text-accent transition-colors">
                    <Bookmark className="w-5 h-5" />
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* Ambassadors Section */}
      <section className="container mx-auto px-4 py-8 pb-24 md:pb-8">
        <Card className="bg-gradient-to-br from-card to-card/50 border-accent/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Trophy className="w-5 h-5 text-accent" />
              <h2 className="text-xl font-bold">Embaixadores Nexus</h2>
            </div>
            <p className="text-muted-foreground mb-6">
              Junte-se ao time de treinadores Nexus e faça parte da comunidade científica.
            </p>
            <div className="flex items-center gap-4 mb-6">
              <div className="flex -space-x-3">
                {ambassadors.map((amb) => (
                  <Avatar key={amb.id} className="w-10 h-10 border-2 border-card">
                    <AvatarImage src={amb.image || "/placeholder.svg"} alt={amb.name} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      {amb.name.split(" ").map(n => n[0]).join("")}
                    </AvatarFallback>
                  </Avatar>
                ))}
                <div className="w-10 h-10 rounded-full bg-primary/20 border-2 border-card flex items-center justify-center">
                  <span className="text-xs text-primary font-medium">+47</span>
                </div>
              </div>
              <span className="text-sm text-muted-foreground">50 treinadores certificados</span>
            </div>
            <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
              Tornar-se Embaixador
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  )
}
