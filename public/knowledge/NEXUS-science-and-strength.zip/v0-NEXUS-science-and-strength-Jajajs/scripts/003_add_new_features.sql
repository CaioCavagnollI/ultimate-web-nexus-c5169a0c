-- Reviews table for books and trainers
CREATE TABLE IF NOT EXISTS reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL DEFAULT 'Usuário Anônimo',
  target_type TEXT NOT NULL CHECK (target_type IN ('book', 'trainer')),
  target_id UUID NOT NULL,
  rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reading progress table
CREATE TABLE IF NOT EXISTS reading_progress (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  book_id UUID NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  current_page INTEGER DEFAULT 0,
  total_pages INTEGER DEFAULT 100,
  last_read_at TIMESTAMPTZ DEFAULT NOW(),
  completed BOOLEAN DEFAULT FALSE,
  bookmarks JSONB DEFAULT '[]',
  notes JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, book_id)
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('purchase', 'new_content', 'promo', 'system', 'ai_response')),
  read BOOLEAN DEFAULT FALSE,
  link TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Purchases/Orders table
CREATE TABLE IF NOT EXISTS purchases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL,
  book_id UUID REFERENCES books(id) ON DELETE SET NULL,
  stripe_session_id TEXT,
  stripe_payment_intent TEXT,
  amount_cents INTEGER NOT NULL,
  currency TEXT DEFAULT 'brl',
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Analytics events table
CREATE TABLE IF NOT EXISTS analytics_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT,
  event_type TEXT NOT NULL,
  event_data JSONB DEFAULT '{}',
  page TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Trainers table (for Nexus Lab)
CREATE TABLE IF NOT EXISTS trainers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  specialty TEXT NOT NULL,
  bio TEXT,
  avatar_url TEXT,
  rating DECIMAL(3,2) DEFAULT 5.0,
  review_count INTEGER DEFAULT 0,
  price_monthly_cents INTEGER NOT NULL,
  is_vip BOOLEAN DEFAULT FALSE,
  certifications JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on new tables
ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE reading_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE analytics_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE trainers ENABLE ROW LEVEL SECURITY;

-- RLS policies - allow all operations for now (no auth yet)
CREATE POLICY "reviews_select_all" ON reviews FOR SELECT USING (true);
CREATE POLICY "reviews_insert_all" ON reviews FOR INSERT WITH CHECK (true);
CREATE POLICY "reviews_update_all" ON reviews FOR UPDATE USING (true);
CREATE POLICY "reviews_delete_all" ON reviews FOR DELETE USING (true);

CREATE POLICY "reading_progress_select_all" ON reading_progress FOR SELECT USING (true);
CREATE POLICY "reading_progress_insert_all" ON reading_progress FOR INSERT WITH CHECK (true);
CREATE POLICY "reading_progress_update_all" ON reading_progress FOR UPDATE USING (true);
CREATE POLICY "reading_progress_delete_all" ON reading_progress FOR DELETE USING (true);

CREATE POLICY "notifications_select_all" ON notifications FOR SELECT USING (true);
CREATE POLICY "notifications_insert_all" ON notifications FOR INSERT WITH CHECK (true);
CREATE POLICY "notifications_update_all" ON notifications FOR UPDATE USING (true);
CREATE POLICY "notifications_delete_all" ON notifications FOR DELETE USING (true);

CREATE POLICY "purchases_select_all" ON purchases FOR SELECT USING (true);
CREATE POLICY "purchases_insert_all" ON purchases FOR INSERT WITH CHECK (true);
CREATE POLICY "purchases_update_all" ON purchases FOR UPDATE USING (true);

CREATE POLICY "analytics_select_all" ON analytics_events FOR SELECT USING (true);
CREATE POLICY "analytics_insert_all" ON analytics_events FOR INSERT WITH CHECK (true);

CREATE POLICY "trainers_select_all" ON trainers FOR SELECT USING (true);
CREATE POLICY "trainers_insert_all" ON trainers FOR INSERT WITH CHECK (true);
CREATE POLICY "trainers_update_all" ON trainers FOR UPDATE USING (true);
CREATE POLICY "trainers_delete_all" ON trainers FOR DELETE USING (true);

-- Insert sample trainers
INSERT INTO trainers (name, specialty, bio, rating, review_count, price_monthly_cents, is_vip, certifications)
VALUES 
  ('Caio Cavagnolli', 'Periodização e Ciência do Treinamento', 'Autor da coleção NEXUS, especialista em periodização científica e treinamento baseado em evidências.', 5.0, 127, 49700, true, '["CREF", "Mestrado em Fisiologia", "Especialização em Biomecânica"]'),
  ('Ana Moreira', 'Nutrição Esportiva', 'Nutricionista esportiva com foco em atletas de força e composição corporal.', 4.8, 89, 29700, false, '["CRN", "Pós-graduação em Nutrição Esportiva"]'),
  ('Rafael Costa', 'Powerlifting', 'Técnico de powerlifting com múltiplos atletas campeões nacionais.', 4.9, 64, 34700, false, '["CREF", "IPF Coach Level 2"]'),
  ('Juliana Santos', 'Reabilitação e Mobilidade', 'Fisioterapeuta especializada em prevenção de lesões e performance.', 4.7, 52, 27700, false, '["CREFITO", "FMS Certified"]')
ON CONFLICT DO NOTHING;

-- Insert sample notifications
INSERT INTO notifications (user_id, title, message, type, link)
VALUES 
  ('demo-user', 'Bem-vindo ao NEXUS!', 'Explore nossa biblioteca de livros científicos sobre treinamento.', 'system', '/library'),
  ('demo-user', 'Novo livro disponível', 'Periodização Científica 2.0 já está disponível na biblioteca.', 'new_content', '/library'),
  ('demo-user', 'Promoção especial', 'Box completo com 51% de desconto por tempo limitado!', 'promo', '/library')
ON CONFLICT DO NOTHING;
