-- Add INSERT and UPDATE policies for books table (for admin operations)
-- Using service role key bypasses RLS, but we also add public insert for simplicity

-- Allow public inserts for books (admin functionality)
CREATE POLICY "Anyone can insert books" ON books FOR INSERT WITH CHECK (true);

-- Allow public updates for books (admin functionality)  
CREATE POLICY "Anyone can update books" ON books FOR UPDATE USING (true);

-- Allow public deletes for books (admin functionality)
CREATE POLICY "Anyone can delete books" ON books FOR DELETE USING (true);

-- Allow public inserts for book_chunks (for uploading book content)
CREATE POLICY "Anyone can insert book chunks" ON book_chunks FOR INSERT WITH CHECK (true);

-- Allow public updates for book_chunks
CREATE POLICY "Anyone can update book chunks" ON book_chunks FOR UPDATE USING (true);

-- Allow public deletes for book_chunks
CREATE POLICY "Anyone can delete book chunks" ON book_chunks FOR DELETE USING (true);
