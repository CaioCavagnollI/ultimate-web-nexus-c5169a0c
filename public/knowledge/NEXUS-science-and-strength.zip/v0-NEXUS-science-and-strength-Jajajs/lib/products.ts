"use server"

import { createClient } from "@/lib/supabase/server"

export interface Product {
  id: string
  name: string
  description: string
  priceInCents: number
  images?: string[]
  type: "book" | "bundle" | "subscription" | "trainer"
  bookId?: string
  trainerId?: string
}

// Static products for subscriptions and bundles
export const STATIC_PRODUCTS: Product[] = [
  {
    id: "box-cavagnolli",
    name: "Box Caio Cavagnolli",
    description: "Coleção completa com 9 livros sobre ciência do treinamento",
    priceInCents: 29700, // R$297.00 (51% off from R$607)
    type: "bundle",
  },
  {
    id: "consultoria-black",
    name: "Consultoria Cavagnolli Black",
    description: "Plano VIP mensal com acesso exclusivo ao mentor",
    priceInCents: 49700, // R$497.00/mês
    type: "subscription",
  },
  {
    id: "ai-mentor-pro",
    name: "AI Mentor Pro",
    description: "Acesso ilimitado ao AI Mentor com respostas prioritárias",
    priceInCents: 4900, // R$49.00/mês
    type: "subscription",
  },
]

// Get all products including books from database
export async function getProducts(): Promise<Product[]> {
  const supabase = await createClient()
  
  const { data: books } = await supabase
    .from("books")
    .select("id, title, description, price")
    .eq("is_published", true)
  
  const bookProducts: Product[] = (books || []).map((book) => ({
    id: `book-${book.id}`,
    name: book.title,
    description: book.description || "",
    priceInCents: Math.round((book.price || 0) * 100),
    type: "book" as const,
    bookId: book.id,
  }))
  
  return [...STATIC_PRODUCTS, ...bookProducts]
}

// Find product by ID
export async function findProduct(productId: string): Promise<Product | undefined> {
  const products = await getProducts()
  return products.find((p) => p.id === productId)
}

// Get trainers as products
export async function getTrainerProducts(): Promise<Product[]> {
  const supabase = await createClient()
  
  const { data: trainers } = await supabase
    .from("trainers")
    .select("id, name, specialty, price_per_month")
    .eq("is_active", true)
  
  return (trainers || []).map((trainer) => ({
    id: `trainer-${trainer.id}`,
    name: `Consultoria com ${trainer.name}`,
    description: trainer.specialty,
    priceInCents: Math.round((trainer.price_per_month || 0) * 100),
    type: "trainer" as const,
    trainerId: trainer.id,
  }))
}
