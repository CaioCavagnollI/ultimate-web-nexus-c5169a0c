import { createClient } from "@/lib/supabase/server"
import { AdminUpload } from "@/components/nexus/admin-upload"

export default async function AdminPage() {
  const supabase = await createClient()
  
  const { data: books } = await supabase
    .from("books")
    .select("id, title")
    .order("title")

  return <AdminUpload existingBooks={books || []} />
}
