import { streamText, convertToModelMessages } from "ai"
import { createClient } from "@/lib/supabase/server"

export async function POST(req: Request) {
  const { messages, sessionId } = await req.json()

  const supabase = await createClient()

  // Get relevant book chunks for RAG context
  const lastUserMessage = messages.filter((m: { role: string }) => m.role === "user").pop()
  const userQuery = lastUserMessage?.parts?.[0]?.text || lastUserMessage?.content || ""

  // Fetch book chunks that might be relevant (simple keyword matching for now)
  // In production, you'd use vector similarity search with embeddings
  const { data: chunks } = await supabase
    .from("book_chunks")
    .select("content, chapter, books(title)")
    .textSearch("content", userQuery.split(" ").slice(0, 5).join(" | "), {
      type: "websearch",
      config: "portuguese",
    })
    .limit(5)

  // Build context from retrieved chunks
  const context = chunks?.length
    ? chunks
        .map(
          (c: { content: string; chapter: string | null; books: { title: string } | null }) =>
            `[Fonte: ${c.books?.title || "Livro"} - ${c.chapter || "Capítulo"}]\n${c.content}`
        )
        .join("\n\n---\n\n")
    : ""

  const systemPrompt = `Você é o Mentor IA do NEXUS, um assistente especializado em treinamento de força, hipertrofia, periodização e biomecânica. Você foi treinado exclusivamente com os livros de Caio Cavagnolli.

DIRETRIZES:
- Responda APENAS sobre temas relacionados a treinamento de força, musculação, periodização, biomecânica, nutrição esportiva e recuperação
- Baseie suas respostas no conhecimento científico dos livros
- Seja didático e use exemplos práticos
- Se a pergunta não for sobre treinamento/fitness, educadamente redirecione o usuário para perguntas relevantes
- Use português brasileiro
- Cite fontes quando possível (ex: "Como explicado no livro Periodização Científica...")

${context ? `CONTEXTO DOS LIVROS (use como referência):\n${context}` : ""}

Responda de forma clara, objetiva e baseada em evidências científicas.`

  const result = streamText({
    model: "openai/gpt-4o-mini",
    system: systemPrompt,
    messages: await convertToModelMessages(messages),
  })

  // Save messages to database for history
  if (sessionId) {
    await supabase.from("chat_messages").insert({
      session_id: sessionId,
      role: "user",
      content: userQuery,
    })
  }

  return result.toUIMessageStreamResponse()
}
